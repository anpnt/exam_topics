function injectPopupHidingStyle() {
    if (!document.getElementById('hide-popup-overlay-extension-style')) {
      const style = document.createElement('style');
      style.id = 'hide-popup-overlay-extension-style';
      style.textContent = `
        .popup-overlay.show {
          display: none !important;
        }
      `;
      document.head.appendChild(style);
    }
  }

  injectPopupHidingStyle();

  const observer = new MutationObserver(injectPopupHidingStyle);
  observer.observe(document.documentElement, { childList: true, subtree: true });